package com.example.ffpainel

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import kotlin.random.Random

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 13, 20)
    private val panel = Color.rgb(18, 27, 39)
    private val mint = Color.rgb(57, 230, 165)
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 24)
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
        home()
    }

    private fun title(text: String, size: Float = 24f) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
    }

    private fun body(text: String) = TextView(this).apply {
        this.text = text
        textSize = 15f
        setTextColor(Color.rgb(190, 202, 216))
        setPadding(0, 8, 0, 8)
    }

    private fun button(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(Color.BLACK)
        setBackgroundColor(mint)
        setOnClickListener { action() }
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(18, 16, 18, 16)
        setBackgroundColor(panel)
        val p = LinearLayout.LayoutParams(-1, -2)
        p.setMargins(0, 10, 0, 10)
        layoutParams = p
    }

    private fun reset(header: String, subtitle: String) {
        root.removeAllViews()
        root.addView(title("FF PAINEL"))
        root.addView(body(subtitle))
        root.addView(title(header, 20f))
    }

    private fun home() {
        reset("Seu painel de apoio", "Ferramentas de configuração e treino — sem modificar o Free Fire.")
        val c1 = card()
        c1.addView(title("01  PAINEL LEGIT", 18f))
        c1.addView(body("Sensibilidade, DPI e orientação de HUD para ajustar manualmente no jogo."))
        c1.addView(button("Abrir configurações") { legit() })
        root.addView(c1)

        val c2 = card()
        c2.addView(title("02  PAINEL VISUAL", 18f))
        c2.addView(body("Interface gamer com atalhos informativos e checklist de configuração."))
        c2.addView(button("Abrir painel visual") { visual() })
        root.addView(c2)

        val c3 = card()
        c3.addView(title("03  PAINEL DE TREINO", 18f))
        c3.addView(body("Pratique reação e precisão com um exercício simples dentro do app."))
        c3.addView(button("Começar treino") { training() })
        root.addView(c3)
        root.addView(body("Dica: teste as configurações no campo de treinamento e ajuste aos poucos."))
    }

    private fun legit() {
        reset("Painel LEGIT", "Sugestões iniciais para você testar. Não existe sensibilidade universal.")
        val c = card()
        c.addView(title("Sensibilidade"))
        val settings = listOf("Geral" to "90–100", "Ponto vermelho" to "85–95", "Mira 2x" to "80–90", "Mira 4x" to "70–85", "AWM" to "20–35")
        settings.forEach { (name, value) -> c.addView(body("$name:  $value")) }
        c.addView(body("DPI: mantenha o padrão do aparelho no começo. Se mudar, faça pequenos ajustes nas configurações do Android."))
        c.addView(body("HUD: deixe o botão de tiro em uma posição confortável; teste tamanho e distância no treinamento."))
        root.addView(c)
        root.addView(button("Voltar") { home() })
    }

    private fun visual() {
        reset("Painel VISUAL", "Atalhos de consulta. Eles não aplicam mudanças automaticamente.")
        val c = card()
        c.addView(title("Checklist rápido"))
        val items = listOf("Conferir sensibilidade no jogo", "Revisar posição do botão de tiro", "Ativar taxa de atualização disponível", "Fechar apps que não está usando", "Testar estabilidade antes de ranqueada")
        items.forEach { item ->
            val cb = CheckBox(this).apply {
                text = item
                setTextColor(Color.WHITE)
                buttonTintList = android.content.res.ColorStateList.valueOf(mint)
            }
            c.addView(cb)
        }
        root.addView(c)
        root.addView(button("Voltar") { home() })
    }

    private fun training() {
        reset("Treino de reação", "Toque no botão assim que ele ficar verde. Faça algumas rodadas e compare.")
        val c = card()
        val result = TextView(this).apply {
            text = "Pronto? Toque em iniciar."
            textSize = 17f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(8, 22, 8, 22)
        }
        c.addView(result)
        val start = button("Iniciar rodada") {
            itDisablePlaceholder()
            result.text = "Prepare-se…"
            val delay = Random.nextLong(1200, 3500)
            android.os.Handler(mainLooper).postDelayed({
                result.text = "AGORA! TOQUE!"
                result.setTextColor(mint)
                val began = System.currentTimeMillis()
                val tap = button("TOCAR AGORA") {
                    val ms = System.currentTimeMillis() - began
                    result.text = "Seu tempo: ${ms} ms"
                    result.setTextColor(Color.WHITE)
                }
                c.addView(tap)
            }, delay)
        }
        c.addView(start)
        root.addView(c)
        root.addView(button("Voltar") { home() })
    }

    private fun itDisablePlaceholder() { }
}
